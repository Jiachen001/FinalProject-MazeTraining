"""
The Maze environment: A grid of tiles.

Red rectangle:          explorer object.

Black rectangles:       hells       [reward = -1].
Yellow bin circle:      gold        [reward = +1].
All other states:       ground      [reward = 0].

"""

import numpy as np
import time
import sys

# import appropriate tkinter package based on your python version
if sys.version_info.major == 2:
    import Tkinter as tk
else:
    import tkinter as tk

UNIT = 40   # pixels
# 8 * 8 grids
MAZE_H = 8  # grid height
MAZE_W = 8  # grid width
# 0: path, 1: wall, 2: target

MAZE = np.array([
    [0., 0., 0., 0., 1., 1., 1., 1.],
    [0., 0., 0., 0., 0., 0., 0., 1.],
    [0., 0., 1., 1., 1., 1., 0., 1.],
    [0., 0., 1., 1., 0., 0., 0., 1.],
    [0., 1., 1., 1., 0., 0., 0., 0.],
    [0., 1., 1., 1., 1., 0., 0., 0.],
    [0., 0., 0., 0., 0., 0., 0., 1.],
    [1., 0., 2., 0., 0., 0., 0., 0.]
])

PosX = 0
PosY = 0
TRACES = np.array([
    [0., 0., 0., 0., 0., 0., 0., 0.],
    [0., 0., 0., 0., 0., 0., 0., 0.],
    [0., 0., 0., 0., 0., 0., 0., 0.],
    [0., 0., 0., 0., 0., 0., 0., 0.],
    [0., 0., 0., 0., 0., 0., 0., 0.],
    [0., 0., 0., 0., 0., 0., 0., 0.],
    [0., 0., 0., 0., 0., 0., 0., 0.],
    [1., 0., 2., 0., 0., 0., 0., 0.]
])
TRACES_Copy = TRACES

class Maze():
    def __init__(self):
        # We need an instance of tk.Tk class. The tk.Tk class is a top-level widget of Tk and serves as the main window of the application.
        self.window = tk.Tk()
        self.window.title('maze with Q-Learning')
        self.window.geometry('{0}x{1}'.format(MAZE_W * UNIT, MAZE_H * UNIT))
        self.action_space = ['u', 'd', 'l', 'r'] # all possible actions
        self.n_actions = len(self.action_space)
        self.build_grid()

    def build_grid(self):
        self.canvas = tk.Canvas(self.window, bg='white',
                           height=MAZE_H * UNIT,
                           width=MAZE_W * UNIT)

        # create grids
        for c in range(0, MAZE_W * UNIT, UNIT):
            x0, y0, x1, y1 = c, 0, c, MAZE_W * UNIT
            self.canvas.create_line(x0, y0, x1, y1)
        for r in range(0, MAZE_H * UNIT, UNIT):
            x0, y0, x1, y1 = 0, r, MAZE_H * UNIT, r
            self.canvas.create_line(x0, y0, x1, y1)

        # create origin point ( It is the center of the first cell in the first row)
        origin = np.array([20, 20])

        # create rectangles
        for i in range(MAZE_W):
            for j in range(MAZE_H):
                # black rectangle as wall
                if MAZE[i,j] == 1.:
                    wall_center = origin + np.array([UNIT * j, UNIT * i])
                    self.canvas.create_rectangle(
            wall_center[0] - 15, wall_center[1] - 15,
            wall_center[0] + 15, wall_center[1] + 15,
            fill='black', tags = 'wall')
                # red rectangle as target
                if MAZE[i,j] == 2.:
                    target_center = origin + np.array([UNIT * j, UNIT * i])
                    self.target = self.canvas.create_rectangle(
            target_center[0] - 15, target_center[1] - 15,
            target_center[0] + 15, target_center[1] + 15,
            fill='red', tags = 'target')

        # create oval (the agent)
        self.player = self.canvas.create_oval(
            origin[0] - 15, origin[1] - 15,
            origin[0] + 15, origin[1] + 15,
            fill='yellow')

        # pack all
        self.canvas.pack()

    def render(self):
        time.sleep(0.1)
        self.window.update()

    def reset(self):
        '''
        Reset the explorer agent at the origin position.
        :return: canvas with the explorer agent at the origin position.
        '''
        self.window.update()
        time.sleep(0.5)
        self.canvas.delete(self.player)
        origin = np.array([20, 20])
        self.player = self.canvas.create_oval(
            origin[0] - 15, origin[1] - 15,
            origin[0] + 15, origin[1] + 15,
            fill='yellow')
        self.PosX = 0
        self.PosY = 0
        TRACES = TRACES_Copy
        # return observation
        return self.canvas.coords(self.player)

    def get_state_reward(self, action):
        # get the current coordinate of explorer
        s = self.canvas.coords(self.player)
        base_action = np.array([0, 0])
        move_tag = False
        # do the action
        if action == 0:   # up
            if s[1] > UNIT:
                if MAZE[self.PosY-1,self.PosX] != 1.:
                    self.PosY -= 1
                    base_action[1] -= UNIT
                    move_tag = True
        elif action == 1:   # down
            if s[1] < (MAZE_H - 1) * UNIT:
                if MAZE[self.PosY+1,self.PosX] != 1.:
                    self.PosY += 1
                    base_action[1] += UNIT
                    move_tag = True
        elif action == 2:   # right
            if s[0] < (MAZE_W - 1) * UNIT:
                if MAZE[self.PosY,self.PosX+1] != 1.:
                    self.PosX += 1
                    base_action[0] += UNIT
                    move_tag = True
        elif action == 3:   # left
            if s[0] > UNIT:
                if MAZE[self.PosY,self.PosX-1] != 1.:
                    self.PosX -= 1
                    base_action[0] -= UNIT
                    move_tag = True
        self.canvas.move(self.player, base_action[0], base_action[1])
        # Tag the cells that has been visited
        if move_tag == True:
            TRACES[self.PosY,self.PosX] += 1
        s_ = self.canvas.coords(self.player)  # next state

        # reward function
        done = False
        if s_ == self.canvas.coords(self.target):
            # get to the target
            reward = 50
            done = True
            s_ = 'terminal'
        # penalty
        else :

            if move_tag == True:
                reward = -0.05
            else:
                reward = -0.25
            if TRACES[self.PosY,self.PosX] > 1:
                    reward -= 0.25

        return s_, reward, done
