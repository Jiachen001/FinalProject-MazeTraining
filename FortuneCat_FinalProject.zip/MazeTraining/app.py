"""
Reinforcement learning maze example.

This script is the main part which controls the update method of this example using q-learning algorithm.
The RL algorithm (Q-learning) is in RL_agent.py.
The environment is presented in maze_env.py.

Red rectangle:          explorer.
Black rectangles:       hells       [reward = -1].
Yellow bin circle:      paradise    [reward = +1].
All other states:       ground      [reward = 0].

"""

from maze_env import Maze
from RL_agent import QLearningTable
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import csv

episode_count = 100 # Number of episodes to run the experiment
episodes = range(episode_count)
movements = [] # Number of movements happened in each episode
rewards = [] # The gained reward in each episode
outcomes = [] # Success/Fail in each episode

'''
This function updates the position of the explorer in the Maze environment based on the actions it chooses.
'''
def run_experiment():

    for episode in episodes:
        print("Episode %s/%s." %(episode+1, episode_count))
        # initial observation;
        observation = env.reset()
        moves = 0
        this_reward = 0
        success = 1
    
        while True:
            # fresh env
            env.render()

            # Q-learning chooses action based on observation
            # we convert observation to str since we want to use them as index for our DataFrame.
            action = q_learning_agent.choose_action(str(observation))

            # RL takes action and gets next observation and reward
            observation_, reward, done = env.get_state_reward(action)
            moves +=1
            this_reward += reward
            
            # terminate the game in advance if the palyer misses
            if this_reward < -50 :
                done = True
                success = 0
            
            # print chhanging e
            epsilon = q_learning_agent.epsilon

            # RL learn from the above transition,
            # Update the Q value for the given tuple
            q_learning_agent.learn(str(observation), action, reward, str(observation_))

            # consider the next observation
            observation = observation_

            # break while loop when end of this episode
            if done:
                # outcome
                if success == 1:
                    outcome = "Success"
                else:
                    outcome = "Failure"
                outcomes.append(success)
                movements.append(moves) # Keep track of the number of movements in this episode
                rewards.append(this_reward) # Keep track of the gained reward in this episode
                # update epsilon
                if q_learning_agent.epsilon > q_learning_agent.epsilon_min:
                    q_learning_agent.epsilon *= q_learning_agent.epsilon_decay
                print("Reward: {0}, Moves: {1}, Epsilon: {2}, Outcome: {3}".format(this_reward, moves,epsilon,outcome))
                break

    # end of game
    print('game over!')
    # export q-table
    q_table_export()
    # Show the results
    plot_reward_movements()


def plot_reward_movements():
    plt.figure()
    plt.subplot(3,1,1)
    plt.plot(episodes, movements)
    plt.xlabel("Episode")
    plt.ylabel("# Movements")

    plt.subplot(3,1,2)
    plt.step(episodes, rewards)
    plt.xlabel("Episode")
    plt.ylabel("Reward")
    # y axis extension for demomstration
    plt.ylim([-52,50])
    
    plt.subplot(3,1,3)
    plt.step(episodes, outcomes)
    plt.xlabel("Episode")
    plt.ylabel("Outcome")
    # y axis extension for demomstration
    plt.ylim([-0.5,1.5])
    
    plt.savefig("rewards_movements_q_learn.png")
    plt.show()

# function to export q-table
def q_table_export():
#    print(q_learning_agent.q_table)
    q_learning_agent.q_table.to_csv("q_table.csv")

if __name__ == "__main__":

    # Craete maze environment
    env = Maze()

    # Create Q-learning agent
    q_learning_agent = QLearningTable(actions=list(range(env.n_actions)))

    # Call run_experiment() function once after given time in milliseconds.
    env.window.after(10, run_experiment)

    # The infinite loop used to run the application, wait for an event to occur and process the event
    # till the window is not closed.
    env.window.mainloop()
